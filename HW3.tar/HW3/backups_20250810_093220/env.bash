export VC_STATIC_HOME=/usr/synopsys/vc_static/P-2019.06-SP2
export VCS_HOME=/usr/synopsys/vcs/P-2019.06-SP2
export VERDI_HOME=${VC_STATIC_HOME}/verdi
export PATH=$VCS_HOME/bin:$VERDI_HOME/bin:$PATH
export SNPS_VCS_INTERNAL_MONET_SHARED_LIBRARY_FLOW=1
export SNPSLMD_LICENSE_FILE=27020@StudentLicenseServer.ucsc-extension.edu
