
============================================================
Assignment 3 – SystemVerilog Assertions Simulation
============================================================

Goal:

This assignment involves writing SystemVerilog Assertions (SVA)
to verify a legacy traffic design module (traffic.v) and simulating
them using a simulator (VCS) to check for correct behavior and
assertion violations.

Directory Structure:
--------------------
 ├── traffic.v            # Design Under Test (DUT) Verilog module
 ├── traffic_tb.v         # Testbench driving the traffic module
 ├── simv                 # Compiled simulation executable (generated)
 ├── waveform.vpd         # Simulation waveform file (optional)
 └── README.txt           # This file

Design Overview:
----------------
- DUT is traffic.v, a legacy hardware design without documentation.
- The testbench traffic_tb.v applies stimulus to DUT signals.
- SystemVerilog Assertions are written to check signal protocols,
  timing, and correctness of data transfers within the DUT.
- Simulation runs with assertions enabled, reporting violations.

Steps Performed:
----------------
1. Navigated to assignment directory:
   cd Desktop/HW3

2. Compiled design and testbench with assertions:
   vcs -full64 traffic.v traffic_tb.v -o simv

3. Ran simulation executable:
   ./simv

4. Observed simulation console output:
   - Checked for assertion pass/fail messages.
   - Verified that no unexpected assertion failures occurred.

5. (Optional) Opened waveform file waveform.vpd in viewer for
   signal and assertion debug.

Results:
--------
- Assertions successfully monitored key protocol properties.
- No assertion failures observed during normal testbench stimulus.
- Simulation confirms correct DUT behavior per assertions.

Attached Files for Submission:
------------------------------
The entire folder containing the below key files; 

1) Design file:            traffic.v
2) Testbench file:         traffic_tb.v
3) This README file:       README.txt

============================================================
End of README
============================================================
